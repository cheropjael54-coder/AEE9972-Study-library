AEE#9972 — Study Notes App

Files:
- index.html: the app
- manifest.webmanifest: Android install metadata
- sw.js: offline app shell
- icons/: app icons

IMPORTANT:
To install as a proper Android app, the files must be hosted on an HTTPS website.
After hosting, open the website in Chrome on your Samsung phone, tap ⋮, then "Install app" or "Add to Home screen".

Notes are saved in the app's browser storage on that device. They are not automatically synced to another phone or backed up online. Keep original copies of important files in My Files or another backup location. Clearing Chrome site data can erase the app's saved notes.
